using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Web;
using System.Web.Services;
using VLF.ERRSecurity ;
using VLF.ERR;
using VLF.DAS.Logic;

namespace VLF.ASI.Interfaces
{
	[WebService(Namespace="http://www.sentinelfm.com")]

	/// <summary>
	/// Summary description for DBFleet.
	/// </summary>
	public class DBFleet : System.Web.Services.WebService
	{
		public DBFleet()
		{
			//CODEGEN: This call is required by the ASP.NET Web Services Designer
			InitializeComponent();
		}

		#region Component Designer generated code
		
		//Required by the Web Services Designer 
		private IContainer components = null;
				
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if(disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);		
		}
		
		#endregion

		#region Fleet/Vehicle Interfaces

      [WebMethod(Description = "Returns XML info for Idling messages of vehicles for a particular Fleet by Fleet ID. XML file format:   [BoxId],[LicensePlate],[VehicleDescription],[VehicleId],[VinNum],[OriginDateTime],[Latitude],[Longitude],[BoxMsgInTypeId],[CustomProp]")]
      public int GetVehiclesIdlingDurationByFleetId(int userId, string SID, int fleetId, 
                                                    DateTime fromDateTime, DateTime toDateTime, ref string xml)
      {
         try
         {
            Trace.WriteLineIf(AppConfig.tsWeb.Enabled|AppConfig.tsMain.TraceVerbose,CLS.Util.TraceFormat(CLS.Def.Enums.TraceSeverity.WebInterfaces,string.Format("GetVehiclesIdlingDurationByFleetId( userId={0}, fleetId={1}, fromDate={2} toDate={3} )", userId, fleetId, fromDateTime, toDateTime )));

				// Authenticate
				LoginManager.GetInstance().SecurityCheck( userId, SID ) ;


				//Authorization
				VLF.DAS.Logic.User   dbUser=new User (Application["ConnectionString"].ToString()); 
				if (!dbUser.ValidateUserFleet(userId,fleetId))
					return Convert.ToInt32(InterfaceError.AuthorizationFailed);

            Fleet dbFleet = null;
            DataSet dsVehiclesInfo = null;
            try
            {
               dbFleet = new Fleet(Application["ConnectionString"].ToString());
               dsVehiclesInfo = dbFleet.GetIdlingDurationForFleetId(fleetId, userId, fromDateTime, toDateTime);
            }
            finally
            {
               if (dbFleet != null)
                  dbFleet.Dispose();
            }

				if(dsVehiclesInfo != null && dsVehiclesInfo.Tables.Count > 0 &&  dsVehiclesInfo.Tables[0].Rows.Count > 0 )
				{
					xml = dsVehiclesInfo.GetXml() ;
				}
				return (int)InterfaceError.NoError ;
         }
			catch( Exception Ex )
			{
				return (int)ASIErrorCheck.CheckError( Ex ) ;
			}			
      }
		
		/// <summary>
		/// Returns vehicle information by fleet id. 
		/// </summary>
		/// <param name="fleetId"></param>
		/// <returns>XML [LicensePlate],[BoxId],[VehicleId],[VinNum],[MakeName],[ModelName],[VehicleTypeName],[StateProvince],[ModelYear],[Color],[Description]</returns>
		/// <exception cref="DASException">Thrown DASException in all other exception cases.</exception>
		[WebMethod(Description="Returns XML of vehicles for a particular Fleet by Fleet ID. XML file format:   [LicensePlate],[BoxId],[VehicleId],[VinNum],[MakeName],[ModelName],[VehicleTypeName],[StateProvince],[ModelYear],[Color],[Description] ")]
		public int  GetVehiclesInfoXMLByFleetId(int userId, string SID, int fleetId, ref string xml)
		{
			try
			{
				Trace.WriteLineIf(AppConfig.tsWeb.Enabled|AppConfig.tsMain.TraceVerbose,CLS.Util.TraceFormat(CLS.Def.Enums.TraceSeverity.WebInterfaces,string.Format("GetVehiclesInfoXMLByFleetId( userId = {0}, fleetId = {1} )", userId, fleetId )));

				// Authenticate
				LoginManager.GetInstance().SecurityCheck( userId, SID ) ;


				//Authorization
				VLF.DAS.Logic.User   dbUser=new User (Application["ConnectionString"].ToString()); 
				if (!dbUser.ValidateUserFleet(userId,fleetId))
					return Convert.ToInt32(InterfaceError.AuthorizationFailed);


				Fleet dbFleet = null;
				DataSet dsVehiclesInfo = null;
				try
				{
					dbFleet = new Fleet(Application["ConnectionString"].ToString());
					dsVehiclesInfo = dbFleet.GetVehiclesInfoByFleetId(fleetId);
				}
				finally
				{
					if(dbFleet != null)
						dbFleet.Dispose();
				}

				if(dsVehiclesInfo != null && dsVehiclesInfo.Tables.Count > 0 &&  dsVehiclesInfo.Tables[0].Rows.Count > 0 )
				{
					xml = dsVehiclesInfo.GetXml() ;
				}
				return (int)InterfaceError.NoError ;
			}
			catch( Exception Ex )
			{
				return (int)ASIErrorCheck.CheckError( Ex ) ;
			}			
		}
		/// <summary>
		/// Returns vehicles last known position information by fleet id. 
		/// </summary>
		/// <param name="fleetId"></param>
		/// <returns>
		/// XML
		/// [LicensePlate],[VehicleId],[BoxId],[DateTimeReceived],[OriginDateTime],
		/// [Latitude],[Longitude],[Speed],[Heading],[SensorMask],[CustomProp],
		/// [StreetAddress],[Description],
		/// [IconTypeId],[IconTypeName],[VehicleTypeName],
		/// [LastStatusDateTime],[LastStatusSensor],[LastStatusSpeed],[PrevStatusDateTime],[PrevStatusSensor],[PrevStatusSpeed],[FwTypeId],[Dormant],[DormantDateTime]
		/// </returns>
		/// <exception cref="DASException">Thrown DASException in all exception cases.</exception>
		[WebMethod(Description="Returns XML of vehicles with last known position information by Fleet ID. XML file format: [LicensePlate],[VehicleId],[BoxId],[DateTimeReceived],[OriginDateTime],[Latitude],[Longitude],[Speed],[Heading],[SensorMask],[CustomProp], [StreetAddress],[Description], [IconTypeId],[IconTypeName],[VehicleTypeName], [LastStatusDateTime],[LastStatusSensor],[LastStatusSpeed],[PrevStatusDateTime],[PrevStatusSensor],[PrevStatusSpeed]")]
		public int  GetVehiclesLastKnownPositionInfo(int userId, string SID, int fleetId, ref string xml)
		{
			try
			{
				Trace.WriteLineIf(AppConfig.tsWeb.Enabled|AppConfig.tsMain.TraceVerbose,CLS.Util.TraceFormat(CLS.Def.Enums.TraceSeverity.WebInterfaces,string.Format("GetVehiclesLastKnownPositionInfo( userId = {0}, fleetId = {1} )", userId, fleetId )));

				// Authenticate 
				LoginManager.GetInstance().SecurityCheck( userId, SID ) ;

				//Authorization
				VLF.DAS.Logic.User   dbUser=new User (Application["ConnectionString"].ToString()); 
				if (!dbUser.ValidateUserFleet(userId,fleetId))
					return Convert.ToInt32(InterfaceError.AuthorizationFailed);


				Fleet dbFleet = null;
				DataSet dsVehiclesInfo = null;
				try
				{
					dbFleet = new Fleet(Application["ConnectionString"].ToString());
					dsVehiclesInfo = dbFleet.GetVehiclesLastKnownPositionInfo(fleetId,userId);
				}
				finally
				{
					if(dbFleet != null)
						dbFleet.Dispose();
				}
				if(dsVehiclesInfo != null && dsVehiclesInfo.Tables.Count > 0 &&  dsVehiclesInfo.Tables[0].Rows.Count > 0 )
				{
					xml = dsVehiclesInfo.GetXml() ;
				}
				return (int)InterfaceError.NoError ;
			}
			catch( Exception Ex )
			{
				return (int)ASIErrorCheck.CheckError( Ex ) ;
			}			
		}
		/// <summary>
		/// Returns vehicles last known position information by fleet id. 
		/// </summary>
		/// <param name="userId"></param>
		/// <param name="SID"></param>
		/// <param name="fleetId"></param>
		/// <param name="fleetId"></param>
		/// <param name="distance"></param>
		/// <param name="landmarkName"></param>
		/// <param name="xml" ref ></param>
		///<returns>
		/// XML
		/// [LicensePlate],[VehicleId],[BoxId],[DateTimeReceived],[OriginDateTime],
		/// [Latitude],[Longitude],[Speed],[Heading],[SensorMask],[CustomProp],
		/// [StreetAddress],[Description]
		/// </returns>
		/// <exception cref="DASException">Thrown DASException in all exception cases.</exception>
		[WebMethod(Description="Returns XML of vehicles with last known position information by Landmark Name , distance from Landmark and Fleet ID. XML file format: [LicensePlate],[VehicleId],[BoxId],[DateTimeReceived],[OriginDateTime],[Latitude],[Longitude],[Speed],[Heading],[SensorMask],[CustomProp],[StreetAddress],[Description]")]
		public int  GetVehiclesLastKnownPositionInfoNearestToLandmark(int userId, string SID, int organizationId, int fleetId, int distance, string landmarkName, ref string xml)
		{
			try
			{
				Trace.WriteLineIf(AppConfig.tsWeb.Enabled|AppConfig.tsMain.TraceVerbose,CLS.Util.TraceFormat(CLS.Def.Enums.TraceSeverity.WebInterfaces,string.Format("GetVehiclesLastKnownPositionInfoNearestToLandmark( userId = {0}, organizationId = {1}, fleetId = {2}, distance = {3}, landmarkName = {4} )",userId,organizationId,fleetId,distance,landmarkName )));
				// Authenticate 
				LoginManager.GetInstance().SecurityCheck( userId, SID ) ;

				//Authorization
				VLF.DAS.Logic.User   dbUser=new User (Application["ConnectionString"].ToString()); 
				if (!dbUser.ValidateUserFleet(userId,fleetId))
					return Convert.ToInt32(InterfaceError.AuthorizationFailed);

				Fleet dbFleet = null;
				try
				{
					dbFleet = new Fleet(Application["ConnectionString"].ToString());
				
					// 1. Retrieve fleet last known position
                    // [LicensePlate],[VehicleId],[BoxId],[OriginDateTime],
                    // [Latitude],[Longitude],[Speed],[Heading],[SensorMask],[StreetAddress],
                    // [Description],[BoxArmed],[LastCommunicatedDateTime],[GeoFenceEnabled],
                    // [IconTypeId],[IconTypeName],[VehicleTypeName],
                    // [LastStatusDateTime],[LastStatusSensor],[LastStatusSpeed],
                    // [PrevStatusDateTime],[PrevStatusSensor],[PrevStatusSpeed].
                    // [FwTypeId],[Dormant],[DormantDateTime]
		            DataSet dsFleetLocation = dbFleet.GetVehiclesLastKnownPositionInfo(fleetId,userId);
					if(dsFleetLocation != null && dsFleetLocation.Tables.Count > 0 && dsFleetLocation.Tables[0].Rows.Count > 0)
					{
						// 2. Retrieve landmark location (lat,lon)
						Organization queryOrganization = null;
						try
						{
							double landmarkLat = 0;
							double landmarkLon = 0;
							queryOrganization = new Organization(Application["ConnectionString"].ToString());
							queryOrganization.GetLandmarkLocation(organizationId,landmarkName, ref landmarkLat, ref landmarkLon);
							VLF.MAP.GeoPoint landmarkCoord = new VLF.MAP.GeoPoint(landmarkLat,landmarkLon);
							VLF.MAP.GeoPoint currVehicleCoord = new VLF.MAP.GeoPoint();

							int distanceBetweenGPS = 0;
							
							#region Create map engine instance
                            VLF.MAP.ClientMapProxy map = null;
							SystemConfig qSystem = null;
							try
							{
								qSystem = new SystemConfig(AppConfig.GetInstance().ConnectionString) ;
								DataSet dsGeoCodeInfo = qSystem.GetUserGeoCodeEngineInfo(userId);
								if(dsGeoCodeInfo != null && dsGeoCodeInfo.Tables.Count > 0 && dsGeoCodeInfo.Tables[0].Rows.Count > 0)
								{
                                    map = new VLF.MAP.ClientMapProxy(VLF.MAP.MapUtilities.ConvertGeoCodersToMapEngine(dsGeoCodeInfo));
								}
								else
								{
									throw new ASIDataNotFoundException("Unable to retrieve map engine info by user=" + userId);
								}
							}
							finally
							{
								if(qSystem != null)
									qSystem.Dispose();
							}
							#endregion
							
							// 4. Filter vehicles located near to landmark
							foreach(DataRow ittr in dsFleetLocation.Tables[0].Rows)
							{
								currVehicleCoord.Latitude = Convert.ToDouble(ittr["Latitude"]);
								currVehicleCoord.Longitude = Convert.ToDouble(ittr["Longitude"]);
								// 5. Calculates distance between landmark and current location
								distanceBetweenGPS = (int)(Math.Round(map.GetDistance(landmarkCoord,currVehicleCoord)));
								if(	(distanceBetweenGPS <= VLF.CLS.Def.Const.unassignedIntValue)||
									(distanceBetweenGPS > distance))
								{
									ittr.Delete();
								}
							}
							xml = dsFleetLocation.GetXml() ;
						}
						finally
						{
							if(queryOrganization != null)
								queryOrganization.Dispose();
						}
					}
				}
				finally
				{
					if(dbFleet != null)
						dbFleet.Dispose();
				}
				return (int)InterfaceError.NoError ;
			}
			catch( Exception Ex )
			{
				return (int)ASIErrorCheck.CheckError( Ex ) ;
			}			
			
		}
        [WebMethod(Description = "Returns XML of vehicles with last known position information by Landmark Name , distance from Landmark and Fleet ID. XML file format: [LicensePlate],[VehicleId],[BoxId],[DateTimeReceived],[OriginDateTime],[Latitude],[Longitude],[Speed],[Heading],[SensorMask],[CustomProp],[StreetAddress],[Description]")]
        public int GetVehiclesLastKnownPositionInfoNearestToLatLon(int userId, string SID, int organizationId, int fleetId, int distance, double lat, double lon, ref string xml)
        {
            try
            {
                Trace.WriteLineIf(AppConfig.tsWeb.Enabled | AppConfig.tsMain.TraceVerbose, CLS.Util.TraceFormat(CLS.Def.Enums.TraceSeverity.WebInterfaces, string.Format("GetVehiclesLastKnownPositionInfoNearestToLatLon( userId = {0}, organizationId = {1}, fleetId = {2}, distance = {3}, lat = {4}, lon = {5} )", userId, organizationId, fleetId, distance, lat, lon)));
                // Authenticate 
                LoginManager.GetInstance().SecurityCheck(userId, SID);

                //Authorization
                VLF.DAS.Logic.User dbUser = new User(Application["ConnectionString"].ToString());
                if (!dbUser.ValidateUserFleet(userId, fleetId))
                    return Convert.ToInt32(InterfaceError.AuthorizationFailed);
                
                Fleet dbFleet = null;
                try
                {
                    dbFleet = new Fleet(Application["ConnectionString"].ToString());

                    // 1. Retrieve fleet last known position
                    DataSet dsFleetLocation = dbFleet.GetVehiclesLastKnownPositionInfo(fleetId, userId);
                    if (dsFleetLocation != null && dsFleetLocation.Tables.Count > 0 && dsFleetLocation.Tables[0].Rows.Count > 0)
                    {
                        // 2. Retrieve landmark location (lat,lon)
                        Organization queryOrganization = null;
                        try
                        {
                            VLF.MAP.GeoPoint searchPosition = new VLF.MAP.GeoPoint(lat, lon);
                            VLF.MAP.GeoPoint currVehicleCoord = new VLF.MAP.GeoPoint();

                            int distanceBetweenGPS = 0;

                            #region Create map engine instance
                            SystemConfig qSystem = null;
                            VLF.MAP.ClientMapProxy map = null;
                            try
                            {
                                qSystem = new SystemConfig(AppConfig.GetInstance().ConnectionString);
                                DataSet dsGeoCodeInfo = qSystem.GetUserGeoCodeEngineInfo(userId);
                                if (dsGeoCodeInfo != null && dsGeoCodeInfo.Tables.Count > 0 && dsGeoCodeInfo.Tables[0].Rows.Count > 0)
                                {
                                    map = new VLF.MAP.ClientMapProxy(VLF.MAP.MapUtilities.ConvertGeoCodersToMapEngine(dsGeoCodeInfo));
                                }
                                else
                                {
                                    throw new ASIDataNotFoundException("Unable to retrieve map engine info by user=" + userId);
                                }
                            }
                            finally
                            {
                                if (qSystem != null)
                                    qSystem.Dispose();
                            }
                            #endregion

                            // 4. Filter vehicles located near to landmark
                            foreach (DataRow ittr in dsFleetLocation.Tables[0].Rows)
                            {
                                currVehicleCoord.Latitude = Convert.ToDouble(ittr["Latitude"]);
                                currVehicleCoord.Longitude = Convert.ToDouble(ittr["Longitude"]);
                                // 5. Calculates distance between landmark and current location
                                distanceBetweenGPS = (int)(Math.Round(map.GetDistance(searchPosition, currVehicleCoord)));
                                if ((distanceBetweenGPS <= VLF.CLS.Def.Const.unassignedIntValue) ||
                                    (distanceBetweenGPS > distance))
                                {
                                    ittr.Delete();
                                }
                            }
                            xml = dsFleetLocation.GetXml();
                        }
                        finally
                        {
                            if (queryOrganization != null)
                                queryOrganization.Dispose();
                        }
                    }
                }
                finally
                {
                    if (dbFleet != null)
                        dbFleet.Dispose();
                }
                return (int)InterfaceError.NoError;
            }
            catch (Exception Ex)
            {
                return (int)ASIErrorCheck.CheckError(Ex);
            }

        }
        /// <summary>
		/// Returns fleets information by vehicle id. 
		/// </summary>
		/// <param name="vehicleId"></param>
		/// <returns>XML [OrganizationName],[FleetName],[FleetDescription]</returns>
		/// <exception cref="DASException">Thrown DASException in all other exception cases.</exception>
		[WebMethod(Description="Returns XML of Fleets this vehicle belongs to by Vehicle ID. XML file format [OrganizationName],[FleetName],[FleetDescription]")]
		public int  GetFleetsInfoXMLByVehicleId(int userId, string SID, Int64 vehicleId, ref string xml)
		{
			try
			{
				Trace.WriteLineIf(AppConfig.tsWeb.Enabled|AppConfig.tsMain.TraceVerbose,CLS.Util.TraceFormat(CLS.Def.Enums.TraceSeverity.WebInterfaces,string.Format("GetFleetsInfoXMLByVehicleId( userId = {0}, vehicleId = {1} )", userId, vehicleId )));

				// Authenticate
				LoginManager.GetInstance().SecurityCheck( userId, SID ) ;


				//Authorization
				VLF.DAS.Logic.User   dbUser=new User (Application["ConnectionString"].ToString()); 
				if (!dbUser.ValidateUserVehicle(userId,vehicleId))
					return Convert.ToInt32(InterfaceError.AuthorizationFailed);

				Fleet dbFleet = null;
				DataSet dsFleetsInfo = null;
				try
				{
					dbFleet = new Fleet(Application["ConnectionString"].ToString());
					dsFleetsInfo = dbFleet.GetFleetsInfoByVehicleId(vehicleId,userId);
				}
				finally
				{
					if(dbFleet != null)
						dbFleet.Dispose();
				}

				if(dsFleetsInfo != null && dsFleetsInfo.Tables.Count > 0 &&  dsFleetsInfo.Tables[0].Rows.Count > 0 )
				{
					xml = dsFleetsInfo.GetXml() ;
				}
				return (int)InterfaceError.NoError ;
			}
			catch( Exception Ex )
			{
				return (int)ASIErrorCheck.CheckError( Ex ) ;
			}			
		}
		/// <summary>
		/// Retreive unassigned to any fleet vehicles.
		/// </summary>
		/// <returns>XML [LicensePlate],[BoxId],[VehicleId],[VinNum],[MakeName],[ModelName],[VehicleTypeName],[StateProvince],[ModelYear],[Color],[Description]</returns>
		/// <exception cref="DASException">Thrown DASException in all other exception cases.</exception>
		[WebMethod(Description="Returns list of vehicles currently unassigned to any Fleet. XML file format: [LicensePlate],[BoxId],[VehicleId],[VinNum],[MakeName],[ModelName],[VehicleTypeName],[StateProvince],[ModelYear],[Color],[Description]")]
		public int GetAllUnassingToFleetsVehiclesInfoXML(int userId, string SID,int organizationId, ref string xml)
		{
			try
			{
				Trace.WriteLineIf(AppConfig.tsWeb.Enabled|AppConfig.tsMain.TraceVerbose,CLS.Util.TraceFormat(CLS.Def.Enums.TraceSeverity.WebInterfaces,string.Format("GetAllUnassingToFleetsVehiclesInfoXML( userId = {0}, organizationId = {1} )", userId, organizationId )));

				// Authenticate & Authorize
				LoginManager.GetInstance().SecurityCheck( userId, SID ) ;

				//Authorization
				VLF.DAS.Logic.User   dbUser=new User (Application["ConnectionString"].ToString()); 
				if (!dbUser.ValidateUserOrganization(userId,organizationId))
					return Convert.ToInt32(InterfaceError.AuthorizationFailed);



				Fleet dbFleet = null;
				DataSet dsInfo = null;
				try
				{
					dbFleet = new Fleet(Application["ConnectionString"].ToString());
					dsInfo = dbFleet.GetAllUnassingToFleetsVehiclesInfo(organizationId);
				}
				finally
				{
					if(dbFleet != null)
						dbFleet.Dispose();
				}

				if(dsInfo != null && dsInfo.Tables.Count > 0 && dsInfo.Tables[0].Rows.Count > 0 )
				{
					xml = dsInfo.GetXml() ;
				}
				return (int)InterfaceError.NoError ;
			}
			catch( Exception Ex )
			{
				return (int)ASIErrorCheck.CheckError( Ex ) ;
			}			
		}
		/// <summary>
		/// Retreive all active vehicles info that unassigned to current fleet.
		/// </summary>
		/// <returns>XML [LicensePlate],[BoxId],[VehicleId],[VinNum],[MakeName],[ModelName],[VehicleTypeName],[StateProvince],[ModelYear],[Color],[Description]</returns>
		/// <exception cref="DASException">Thrown DASException in all other exception cases.</exception>
		[WebMethod(Description="Returns all active vehicles that unassigned to current Fleet.XML file format: XML [LicensePlate],[BoxId],[VehicleId],[VinNum],[MakeName],[ModelName],[VehicleTypeName],[StateProvince],[ModelYear],[Color],[Description]")]
		public int GetAllUnassingToFleetVehiclesInfoXML(int userId, string SID,int organizationId, int fleetId,ref string xml)
		{
			try
			{
				Trace.WriteLineIf(AppConfig.tsWeb.Enabled|AppConfig.tsMain.TraceVerbose,CLS.Util.TraceFormat(CLS.Def.Enums.TraceSeverity.WebInterfaces,string.Format("GetAllUnassingToFleetVehiclesInfoXML( userId = {0}, organizationId = {1}, fleetId = {2} )", userId, organizationId, fleetId )));

				// Authenticate & Authorize
				LoginManager.GetInstance().SecurityCheck( userId, SID ) ;


				//Authorization
				VLF.DAS.Logic.User   dbUser=new User (Application["ConnectionString"].ToString()); 
				if (!dbUser.ValidateUserOrganization(userId,organizationId))
					return Convert.ToInt32(InterfaceError.AuthorizationFailed);


				//Authorization
				dbUser=new User (Application["ConnectionString"].ToString()); 
				if (!dbUser.ValidateUserFleet(userId,fleetId))
					return Convert.ToInt32(InterfaceError.AuthorizationFailed);


				Fleet dbFleet = null;
				DataSet dsInfo = null;
				try
				{
					dbFleet = new Fleet(Application["ConnectionString"].ToString());
					dsInfo = dbFleet.GetAllUnassingToFleetVehiclesInfo(organizationId,fleetId);
				}
				finally
				{
					if(dbFleet != null)
						dbFleet.Dispose();
				}

				if(dsInfo != null && dsInfo.Tables.Count > 0 && dsInfo.Tables[0].Rows.Count > 0 )
				{
					xml = dsInfo.GetXml() ;
				}
				return (int)InterfaceError.NoError ;
			}
			catch( Exception Ex )
			{
				return (int)ASIErrorCheck.CheckError( Ex ) ;
			}			
		}
		[WebMethod(Description="Remove a vehicle from the Fleet.")]
		public int DeleteVehicleFromFleet(int userId, string SID, int fleetId,Int64 vehicleId)
		{
			try
			{
				Trace.WriteLineIf(AppConfig.tsWeb.Enabled|AppConfig.tsMain.TraceVerbose,CLS.Util.TraceFormat(CLS.Def.Enums.TraceSeverity.WebInterfaces,string.Format("DeleteVehicleFromFleet( userId = {0}, fleetId = {1}, vehicleId = {2} )", userId, fleetId, vehicleId )));

				// Authenticate & Authorize
				LoginManager.GetInstance().SecurityCheck( userId, SID ) ;


				//Authorization
				VLF.DAS.Logic.User   dbUser=new User (Application["ConnectionString"].ToString()); 
				if (!dbUser.ValidateUserFleet(userId,fleetId))
					return Convert.ToInt32(InterfaceError.AuthorizationFailed);

				//Authorization
				dbUser=new User (Application["ConnectionString"].ToString()); 
				if (!dbUser.ValidateUserVehicle(userId,vehicleId))
					return Convert.ToInt32(InterfaceError.AuthorizationFailed);

				Fleet dbFleet = null;
				try
				{
					dbFleet = new Fleet(Application["ConnectionString"].ToString());
					dbFleet.DeleteVehicleFromFleet(fleetId,vehicleId);
				}
				finally
				{
					if(dbFleet != null)
						dbFleet.Dispose();
				}
				return (int)InterfaceError.NoError ;
			}
			catch( Exception Ex )
			{
				return (int)ASIErrorCheck.CheckError( Ex ) ;
			}
		}
		[WebMethod(Description="Assign a vehicle to Fleet.")]
		public int AddVehicleToFleet(int userId, string SID, int fleetId,Int64 vehicleId)
		{
			try
			{
				Trace.WriteLineIf(AppConfig.tsWeb.Enabled|AppConfig.tsMain.TraceVerbose,CLS.Util.TraceFormat(CLS.Def.Enums.TraceSeverity.WebInterfaces,string.Format("AddVehicleToFleet( userId = {0}, fleetId = {1}, vehicleId = {2} )", userId, fleetId, vehicleId )));

				// Authenticate & Authorize
				LoginManager.GetInstance().SecurityCheck( userId, SID ) ;


				//Authorization
				VLF.DAS.Logic.User dbUser=new User (Application["ConnectionString"].ToString()); 
				if (!dbUser.ValidateSuperUser(userId))
					return Convert.ToInt32(InterfaceError.AuthorizationFailed);

				Fleet dbFleet = null;
				try
				{
					dbFleet = new Fleet(Application["ConnectionString"].ToString());
					dbFleet.AddVehicleToFleet(fleetId,vehicleId);
				}
				finally
				{
					if(dbFleet != null)
						dbFleet.Dispose();
				}
				return (int)InterfaceError.NoError ;
			}
			catch( Exception Ex )
			{
				return (int)ASIErrorCheck.CheckError( Ex ) ;
			}
		}
		/// <summary>
		/// Returns all vehicles active assignment configuration information for current organization
		/// </summary>
		/// <param name="fleetId"></param>
		/// <returns>XML [Description],[BoxId],[FwId],[FwName],[FwDateReleased]</returns>
		/// <exception cref="DASException">Thrown DASException in all other exception cases.</exception>
		[WebMethod(Description="Returns XML of vehicles for a particular Fleet by Fleet ID. XML file format:   [Description],[BoxId],[FwId],[FwName],[FwDateReleased]")]
		public int  GetFleetAllActiveVehiclesCfgInfo(int userId, string SID, int fleetId, ref string xml)
		{
			try
			{
				Trace.WriteLineIf(AppConfig.tsWeb.Enabled|AppConfig.tsMain.TraceVerbose,CLS.Util.TraceFormat(CLS.Def.Enums.TraceSeverity.WebInterfaces,string.Format("GetFleetAllActiveVehiclesCfgInfo( userId = {0}, fleetId = {1} )", userId, fleetId )));

				// Authenticate & Authorize
				LoginManager.GetInstance().SecurityCheck( userId, SID ) ;


				//Authorization
				VLF.DAS.Logic.User   dbUser=new User (Application["ConnectionString"].ToString()); 
				if (!dbUser.ValidateUserFleet(userId,fleetId))
					return Convert.ToInt32(InterfaceError.AuthorizationFailed);


				Fleet dbFleet = null;
				DataSet dsVehiclesInfo = null;
				try
				{
					dbFleet = new Fleet(Application["ConnectionString"].ToString());
					dsVehiclesInfo = dbFleet.GetFleetAllActiveVehiclesCfgInfo(fleetId);
				}
				finally
				{
					if(dbFleet != null)
						dbFleet.Dispose();
				}

				if(dsVehiclesInfo != null && dsVehiclesInfo.Tables.Count > 0 &&  dsVehiclesInfo.Tables[0].Rows.Count > 0 )
				{
					xml = dsVehiclesInfo.GetXml() ;
				}
				return (int)InterfaceError.NoError ;
			}
			catch( Exception Ex )
			{
				return (int)ASIErrorCheck.CheckError( Ex ) ;
			}			
		}
        [WebMethod(Description = "Retrieves vehicle maintenance information . XML File format :[BoxId],[VehicleId],[Description],[LastSrvOdo],[CurrentOdo],[MaxSrvInterval],[LastSrvEngHrs],[CurrentEngHrs],[EngHrsSrvInterval],[Email],[TimeZone],[DayLightSaving],[AutoAdjustDayLightSaving],[LicensePlate],[ModelYear],[MakeName],[ModelName],[NextServiceDescription],[VehicleTypeId]")]
        public int GetFleetMaintenanceInfoXML(int userId, string SID, int fleetId, ref string xml)
        {
            try
            {
                Trace.WriteLineIf(AppConfig.tsWeb.Enabled | AppConfig.tsMain.TraceVerbose, CLS.Util.TraceFormat(CLS.Def.Enums.TraceSeverity.WebInterfaces, string.Format("GetFleetMaintenanceInfoXML( userId = {0}, fleetId = {1} )", userId, fleetId)));

                // Authenticate & Authorize
                LoginManager.GetInstance().SecurityCheck(userId, SID);


                //Authorization
                VLF.DAS.Logic.User dbUser = new User(Application["ConnectionString"].ToString());
                // By designe, this method allows user to see all fleets (even not ussigned to this user!!!) maintenace information.
                if (!dbUser.ValidateUserOrganization(userId, dbUser.GetOrganizationIdByUserId(userId)))
                    return Convert.ToInt32(InterfaceError.AuthorizationFailed);

                DataSet dsFleetInfo = null;
                Fleet dbFleet = null;
                try
                {
                    dbFleet = new Fleet(Application["ConnectionString"].ToString());
                    dsFleetInfo = dbFleet.GetFleetMaintenanceInfo(fleetId,userId);
                }
                finally
                {
                    if (dbFleet != null)
                        dbFleet.Dispose();
                }
                if (dsFleetInfo != null && dsFleetInfo.Tables.Count > 0 && dsFleetInfo.Tables[0].Rows.Count > 0)
                    xml = dsFleetInfo.GetXml();

                return (int)InterfaceError.NoError;
            }
            catch (Exception Ex)
            {
                return (int)ASIErrorCheck.CheckError(Ex);
            }
        }
        [WebMethod(Description = "Retrieves vehicle maintenance information . XML File format :[VehicleId],[ServiceDateTime],[ServiceDescription],[ServiceOdo]")]
        public int GetFleetMaintenanceHistoryXML(int userId, string SID, int fleetId, ref string xml)
        {
            try
            {
                Trace.WriteLineIf(AppConfig.tsWeb.Enabled | AppConfig.tsMain.TraceVerbose, CLS.Util.TraceFormat(CLS.Def.Enums.TraceSeverity.WebInterfaces, string.Format("GetFleetMaintenanceHistoryXML( userId = {0}, fleetId = {1} )", userId, fleetId)));

                // Authenticate & Authorize
                LoginManager.GetInstance().SecurityCheck(userId, SID);


                //Authorization
                VLF.DAS.Logic.User dbUser = new User(Application["ConnectionString"].ToString());
                // By designe, this method allows user to see all fleets (even not ussigned to this user!!!) maintenace information.
                if (!dbUser.ValidateUserOrganization(userId, dbUser.GetOrganizationIdByUserId(userId)))
                    return Convert.ToInt32(InterfaceError.AuthorizationFailed);

                DataSet dsFleetInfo = null;
                Fleet dbFleet = null;
                try
                {
                    dbFleet = new Fleet(Application["ConnectionString"].ToString());
                    dsFleetInfo = dbFleet.GetFleetMaintenanceHistory(fleetId, userId);
                }
                finally
                {
                    if (dbFleet != null)
                        dbFleet.Dispose();
                }
                if (dsFleetInfo != null && dsFleetInfo.Tables.Count > 0 && dsFleetInfo.Tables[0].Rows.Count > 0)
                    xml = dsFleetInfo.GetXml();

                return (int)InterfaceError.NoError;
            }
            catch (Exception Ex)
            {
                return (int)ASIErrorCheck.CheckError(Ex);
            }
        }


      [WebMethod(Description = "Retrieves history information by Fleet ID.  XML File format:[BoxId],[DateTimeReceived],[OriginDateTime],[DclId],[BoxMsgInTypeId],[BoxMsgInTypeName],[BoxProtocolTypeId],[BoxProtocolTypeName],[CommInfo1],[CommInfo2],[ValidGps],[Latitude],[Longitude],[Speed],[Heading],[SensorMask],[CustomProp],[BlobDataSize], [StreetAddress],[SequenceNum],[BoxArmed],[MsgDetails],[MsgDirection],[Acknowledged],[Scheduled]")]
        public int GetMessagesFromHistoryByFleetId(int userId, string SID, int fleetId,string fromDateTime, string toDateTime, ref string xml)
        {
            try
            {
                Trace.WriteLineIf(AppConfig.tsWeb.Enabled | AppConfig.tsMain.TraceVerbose, CLS.Util.TraceFormat(CLS.Def.Enums.TraceSeverity.WebInterfaces, string.Format("GetFleetMaintenanceHistoryXML( userId = {0}, fleetId = {1} )", userId, fleetId)));

                // Authenticate & Authorize
                LoginManager.GetInstance().SecurityCheck(userId, SID);


                //Authorization
                VLF.DAS.Logic.User dbUser = new User(Application["ConnectionString"].ToString());
                // By designe, this method allows user to see all fleets (even not ussigned to this user!!!) maintenace information.
                if (!dbUser.ValidateUserOrganization(userId, dbUser.GetOrganizationIdByUserId(userId)))
                    return Convert.ToInt32(InterfaceError.AuthorizationFailed);

                DataSet dsFleetInfo = null;
                MessageQueue dbMsg = null;
                try
                {
                   dbMsg = new MessageQueue(Application["ConnectionString"].ToString());

                   TimeSpan ts = Convert.ToDateTime(toDateTime) - Convert.ToDateTime(fromDateTime);
                   if (ts.TotalHours < 3)
                      dsFleetInfo = dbMsg.GetMessagesFromHistoryByFleetId(fleetId, Convert.ToDateTime(fromDateTime), Convert.ToDateTime(toDateTime));
                   else
                      dsFleetInfo = dbMsg.GetMessagesFromHistoryByFleetId(fleetId, Convert.ToDateTime(fromDateTime), Convert.ToDateTime(fromDateTime).AddHours(3));
                }
                finally
                {
                    if (dbMsg != null)
                        dbMsg.Dispose();
                }
                if (dsFleetInfo != null && dsFleetInfo.Tables.Count > 0 && dsFleetInfo.Tables[0].Rows.Count > 0)
                    xml = dsFleetInfo.GetXml();
              

                return (int)InterfaceError.NoError;
            }
            catch (Exception Ex)
            {
                return (int)ASIErrorCheck.CheckError(Ex);
            }
        }

        /// <summary>
        /// Returns vehicle information by fleet id, filtered by feature mask
        /// </summary>
        /// <param name="fleetId">Fleet Id</param>
        /// <param name="featureMask">Feature mask</param>
        /// <returns>XML [LicensePlate],[BoxId],[VehicleId],[VinNum],[MakeName],[ModelName],[VehicleTypeName],[StateProvince],[ModelYear],[Color],[Description]</returns>
        /// <exception cref="DASException">Thrown DASException in all other exception cases.</exception>
        [WebMethod(Description = "Returns XML of vehicles for a particular Fleet by Fleet ID. XML file format: [LicensePlate],[BoxId],[VehicleId],[VinNum],[MakeName],[ModelName],[VehicleTypeName],[StateProvince],[ModelYear],[Color],[Description]")]
        public int GetVehiclesInfoXMLByFleetIdFeatures(int userId, string SID, int fleetId, long featureMask, ref string xml)
        {
           try
           {
              Trace.WriteLineIf(AppConfig.tsWeb.Enabled | AppConfig.tsMain.TraceVerbose, CLS.Util.TraceFormat(CLS.Def.Enums.TraceSeverity.WebInterfaces, string.Format("GetVehiclesInfoXMLByFleetId( userId = {0}, fleetId = {1} )", userId, fleetId)));

              // Authenticate
              LoginManager.GetInstance().SecurityCheck(userId, SID);

              //Authorization
              VLF.DAS.Logic.User dbUser = new User(Application["ConnectionString"].ToString());
              if (!dbUser.ValidateUserFleet(userId, fleetId))
                 return Convert.ToInt32(InterfaceError.AuthorizationFailed);


              Fleet dbFleet = null;
              DataSet dsVehiclesInfo = null;
              try
              {
                 dbFleet = new Fleet(Application["ConnectionString"].ToString());
                 dsVehiclesInfo = dbFleet.GetVehiclesInfoByFleetId(fleetId, featureMask);
              }
              finally
              {
                 if (dbFleet != null)
                    dbFleet.Dispose();
              }

              if (dsVehiclesInfo != null && dsVehiclesInfo.Tables.Count > 0 && dsVehiclesInfo.Tables[0].Rows.Count > 0)
              {
                 xml = dsVehiclesInfo.GetXml();
              }
              return (int)InterfaceError.NoError;
           }
           catch (Exception Ex)
           {
              return (int)ASIErrorCheck.CheckError(Ex);
           }
        }

        #endregion

		#region Fleet Interfaces
		/// <summary>
		/// Delete existing fleet.
		/// </summary>
		/// <param name="fleetId"></param> 
		/// <returns>Rows Affected</returns>
		/// <exception cref="DASException">Thrown DASException in all exception cases.</exception>
		[WebMethod(Description="Delete existing Fleet.")]
		public int DeleteFleetByFleetId(int userId, string SID,int fleetId)
		{
			try
			{
				Trace.WriteLineIf(AppConfig.tsWeb.Enabled|AppConfig.tsMain.TraceVerbose,CLS.Util.TraceFormat(CLS.Def.Enums.TraceSeverity.WebInterfaces,string.Format("DeleteFleetByFleetId( userId = {0}, fleetId = {1} )", userId, fleetId )));

				// Authenticate
				LoginManager.GetInstance().SecurityCheck( userId, SID ) ;


				//Authorization
				VLF.DAS.Logic.User   dbUser=new User (Application["ConnectionString"].ToString()); 
				if (!dbUser.ValidateUserFleet(userId,fleetId))
					return Convert.ToInt32(InterfaceError.AuthorizationFailed);



				// Authorize
				// TODO: 11 - > DeleteFleet
				LoginManager.GetInstance().AuthorizeOperation(userId,VLF.CLS.Def.Enums.OperationType.Gui,11);

				Fleet dbFleet = null;
				try
				{
					dbFleet = new Fleet(Application["ConnectionString"].ToString());
					dbFleet.DeleteFleetByFleetId(fleetId);
				}
				finally
				{
					if(dbFleet != null)
						dbFleet.Dispose();
				}
				return (int)InterfaceError.NoError ;
			}
			catch( Exception Ex )
			{
				return (int)ASIErrorCheck.CheckError( Ex ) ;
			}
		}

		/// <summary>
		/// Add new fleet.
		/// - Add new fleet
		/// </summary>
		/// <param name="fleetName"></param>
		/// <param name="organizationId"></param>
		/// <param name="description"></param>
		/// <returns>int next fleet id</returns>
		/// <exception cref="DASAppDataAlreadyExistsException">Thrown if fleet alredy exists.</exception>
		/// <exception cref="DASAppInvalidValueException">Thrown in case of incorrect value.</exception>
		/// <exception cref="DASException">Thrown DASException in all other exception cases.</exception>
		[WebMethod(Description="Add a new Fleet.")]
		public int AddFleet(int userId, string SID,string fleetName,int organizationId,string description,ref int fleetId)
		{
			try
			{
				Trace.WriteLineIf(AppConfig.tsWeb.Enabled|AppConfig.tsMain.TraceVerbose,CLS.Util.TraceFormat(CLS.Def.Enums.TraceSeverity.WebInterfaces,string.Format("AddFleet( userId = {0}, fleetName = {1}, organizationId = {2}, description = {3} )",userId,SID,fleetName,organizationId,description )));

				// Authenticate 
				LoginManager.GetInstance().SecurityCheck( userId, SID ) ;


				//Authorization
				VLF.DAS.Logic.User   dbUser=new User (Application["ConnectionString"].ToString()); 
				if (!dbUser.ValidateUserOrganization(userId,organizationId))
					return Convert.ToInt32(InterfaceError.AuthorizationFailed);


				// Authorize
				// TODO: 10 - > DeleteFleet
				LoginManager.GetInstance().AuthorizeOperation(userId,VLF.CLS.Def.Enums.OperationType.Gui,10);

				Fleet dbFleet = null;
				try
				{
					dbFleet = new Fleet(Application["ConnectionString"].ToString());
					fleetId = dbFleet.AddFleet (fleetName,organizationId,description);
				}
				finally
				{
					if(dbFleet != null)
						dbFleet.Dispose();
				}
				return (int)InterfaceError.NoError ;
			}
			catch( Exception Ex )
			{
				return (int)ASIErrorCheck.CheckError( Ex ) ;
			}
		}
		//// <summary>
		/// Retrieves Fleet info
		/// </summary>
		/// <returns>XML [FleetId],[FleetName],[Description],[OrganizationId],[OrganizationName]</returns>
		/// <param name="fleetId" param size = int (4 bytes)></param> 
		/// <exception cref="DASException">Thrown DASException in all  exception cases.</exception>
		[WebMethod(Description="Retrieves Fleet information.XML File format: [FleetId],[FleetName],[Description],[OrganizationId],[OrganizationName]")]
		public int GetFleetInfoXMLByFleetId(int userId, string SID, int fleetId,ref string xml)
		{
			try
			{
				Trace.WriteLineIf(AppConfig.tsWeb.Enabled|AppConfig.tsMain.TraceVerbose,CLS.Util.TraceFormat(CLS.Def.Enums.TraceSeverity.WebInterfaces,string.Format("GetFleetInfoXMLByFleetId( userId = {0}, fleetId = {1} )", userId, fleetId )));

				// Authenticate 
				LoginManager.GetInstance().SecurityCheck( userId, SID ) ;

				//Authorization
				VLF.DAS.Logic.User   dbUser=new User (Application["ConnectionString"].ToString()); 
				if (!dbUser.ValidateUserFleet(userId,fleetId))
					return Convert.ToInt32(InterfaceError.AuthorizationFailed);



				// Authorize
				// TODO: 9 - > GetFleetInfo
				LoginManager.GetInstance().AuthorizeOperation(userId,VLF.CLS.Def.Enums.OperationType.Gui,9);
				
				DataSet dsInfo = null;
				Fleet dbFleet = null;
				try
				{
					dbFleet = new Fleet(Application["ConnectionString"].ToString());
					dsInfo = dbFleet.GetFleetInfoByFleetId(fleetId);
				}
				finally
				{
					if(dbFleet != null)
						dbFleet.Dispose();
				}

				if(dsInfo != null && dsInfo.Tables.Count > 0 && dsInfo.Tables[0].Rows.Count > 0)
				{
					xml = dsInfo.GetXml() ;
				}
				return (int)InterfaceError.NoError ;
			}
			catch( Exception Ex )
			{
				return (int)ASIErrorCheck.CheckError( Ex ) ;
			}			
		}
		[WebMethod(Description="Update a Fleet information.")]
		public int UpdateFleetInfo(int userId, string SID,int fleetId,string fleetName,int organizationId,string description)
		{
			try
			{
				Trace.WriteLineIf(AppConfig.tsWeb.Enabled|AppConfig.tsMain.TraceVerbose,CLS.Util.TraceFormat(CLS.Def.Enums.TraceSeverity.WebInterfaces,string.Format("UpdateFleetInfo( fleetId = {0}, fleetName = {1} , organizationId = {2} , description = {3} )", fleetId,fleetName,organizationId,description )));

				// Authenticate 
				LoginManager.GetInstance().SecurityCheck( userId, SID ) ;


				//Authorization
				VLF.DAS.Logic.User   dbUser=new User (Application["ConnectionString"].ToString()); 
				if (!dbUser.ValidateUserFleet(userId,fleetId))
					return Convert.ToInt32(InterfaceError.AuthorizationFailed);



				// Authorize
				// TODO: 12 - > UpdateFleetInfo
				LoginManager.GetInstance().AuthorizeOperation(userId,VLF.CLS.Def.Enums.OperationType.Gui,12);
				
				Fleet dbFleet = null;
				try
				{
					dbFleet = new Fleet(Application["ConnectionString"].ToString());
					dbFleet.UpdateInfo(fleetId,fleetName,organizationId,description);
				}
				finally
				{
					if(dbFleet != null)
						dbFleet.Dispose();
				}
				return (int)InterfaceError.NoError ;
			}
			catch( Exception Ex )
			{
				return (int)ASIErrorCheck.CheckError( Ex ) ;
			}	
		}
		#endregion

		#region Fleet/User Interfaces
		/// <summary>
		/// Returns fleets information by user id. 
		/// </summary>
		/// <param name="userId"></param>
		/// <returns>XML [OrganizationName],[FleetId],[FleetName],[FleetDescription]</returns>
		/// <exception cref="DASException">Thrown DASException in all other exception cases.</exception>
		[WebMethod(Description="Returns XML of Fleets by User ID . XML [OrganizationName],[FleetId],[FleetName],[FleetDescription]")]
		public int GetFleetsInfoXMLByUserId(int userId, string SID, ref string xml)
		{
			try
			{
				Trace.WriteLineIf(AppConfig.tsWeb.Enabled|AppConfig.tsMain.TraceVerbose,CLS.Util.TraceFormat(CLS.Def.Enums.TraceSeverity.WebInterfaces,string.Format("GetFleetsInfoXMLByUserId( userId = {0} )", userId )));

				// Authenticate & Authorize
				LoginManager.GetInstance().SecurityCheck( userId, SID ) ;

				DataSet dsInfo = null;
				Fleet dbFleet = null;
				try
				{
					dbFleet = new Fleet(Application["ConnectionString"].ToString());
					dsInfo = dbFleet.GetFleetsInfoByUserId(userId);
				}
				finally
				{
					if(dbFleet != null)
						dbFleet.Dispose();
				}
				if(dsInfo != null && dsInfo.Tables.Count > 0 && dsInfo.Tables[0].Rows.Count > 0 )
				{
					xml = dsInfo.GetXml() ;
				}
				return (int)InterfaceError.NoError ;
			}
			catch( Exception Ex )
			{
				return (int)ASIErrorCheck.CheckError( Ex ) ;
			}			
		}



      [WebMethod(Description = "Returns XML of Fleets by User ID . XML [OrganizationName],[FleetId],[FleetName],[FleetDescription]")]
      public int GetFleetsInfoXMLByUserIdByLang(int userId, string SID,string lang, ref string xml)
      {
         try
         {
            Trace.WriteLineIf(AppConfig.tsWeb.Enabled | AppConfig.tsMain.TraceVerbose, CLS.Util.TraceFormat(CLS.Def.Enums.TraceSeverity.WebInterfaces, string.Format("GetFleetsInfoXMLByUserId( userId = {0} )", userId)));

            // Authenticate & Authorize
            LoginManager.GetInstance().SecurityCheck(userId, SID);

            DataSet dsInfo = null;
            Fleet dbFleet = null;
            try
            {
               dbFleet = new Fleet(Application["ConnectionString"].ToString());
               dsInfo = dbFleet.GetFleetsInfoByUserId(userId);
            }
            finally
            {
               if (dbFleet != null)
                  dbFleet.Dispose();
            }
            if (dsInfo != null && dsInfo.Tables.Count > 0 && dsInfo.Tables[0].Rows.Count > 0)
            {
               xml = dsInfo.GetXml();
            }

            if (lang != "en")
            {
                Resources.Const.Culture = new System.Globalization.CultureInfo(lang);
                xml = xml.Replace(VLF.CLS.Def.Const.defaultFleetName, Resources.Const.defaultFleetName);
            }

            return (int)InterfaceError.NoError;
         }
         catch (Exception Ex)
         {
            return (int)ASIErrorCheck.CheckError(Ex);
         }
      }

		/// <summary>
		/// Returns all users info by fleet id. 
		/// </summary>
		/// <param name="fleetId"></param>
		/// <returns>XML [UserId],[UserName],[Password],[DriverLicense],[FirstName],[LastName],[ContactInfo],[OrganizationId]</returns>
		/// <exception cref="DASException">Thrown DASException in all other exception cases.</exception>
		[WebMethod(Description="Returns XML of users assigned to fleet. XML file format: [UserId],[UserName],[Password],[DriverLicense],[FirstName],[LastName],[ContactInfo],[OrganizationId]")]
		public int GetUsersInfoXMLByFleetId(int userId, string SID, int fleetId, ref string xml)
		{
			try
			{
				Trace.WriteLineIf(AppConfig.tsWeb.Enabled|AppConfig.tsMain.TraceVerbose,CLS.Util.TraceFormat(CLS.Def.Enums.TraceSeverity.WebInterfaces,string.Format(" GetUsersInfoXMLByFleetId( userId = {0}, fleetId = {1} )", userId, fleetId )));

				// Authenticate 
				LoginManager.GetInstance().SecurityCheck( userId, SID ) ;


				//Authorization
				VLF.DAS.Logic.User   dbUser=new User (Application["ConnectionString"].ToString()); 
				if (!dbUser.ValidateUserFleet(userId,fleetId))
					return Convert.ToInt32(InterfaceError.AuthorizationFailed);



				// Authorize
				// TODO: 15 - > ViewFleetUsers
				LoginManager.GetInstance().AuthorizeOperation(userId,VLF.CLS.Def.Enums.OperationType.Gui,15);
		
				DataSet dsInfo = null;
				Fleet dbFleet = null;
				try
				{
					dbFleet = new Fleet(Application["ConnectionString"].ToString());
					dsInfo = dbFleet.GetUsersInfoByFleetId(fleetId);
				}
				finally
				{
					if(dbFleet != null)
						dbFleet.Dispose();
				}

				if(dsInfo != null && dsInfo.Tables.Count > 0 && dsInfo.Tables[0].Rows.Count > 0 )
					xml = dsInfo.GetXml() ;
				return (int)InterfaceError.NoError ;
			}
			catch( Exception Ex )
			{
				return (int)ASIErrorCheck.CheckError( Ex ) ;
			}			
		}
		/// <summary>
		/// Retieves all users unassigned to the fleet
		/// </summary>
		/// <param name="userId"></param>
		/// <param name="fleetId"></param>
		/// <returns>XML [UserId],[UserName],[Password],[DriverLicense],[FirstName],[LastName],[ContactInfo],[OrganizationId]</returns>
		/// <exception cref="DASException">Thrown DASException in all other exception cases.</exception>
		[WebMethod(Description="Returns XML of users , that not assigned to specific fleet. XML file format: [UserId],[UserName],[Password],[DriverLicense],[FirstName],[LastName],[ContactInfo],[OrganizationId]")]
		public int GetUnassignedUsersInfoXMLByFleetId(int userId, string SID, int fleetId, ref string xml)
		{
			try
			{
				Trace.WriteLineIf(AppConfig.tsWeb.Enabled|AppConfig.tsMain.TraceVerbose,CLS.Util.TraceFormat(CLS.Def.Enums.TraceSeverity.WebInterfaces,string.Format("GetUnassignedUsersInfoXMLByFleetId( userId = {0}, fleetId = {1} )", userId,fleetId )));

				// Authenticate
				LoginManager.GetInstance().SecurityCheck( userId, SID ) ;

				//Authorization
				VLF.DAS.Logic.User   dbUser=new User (Application["ConnectionString"].ToString()); 
				if (!dbUser.ValidateUserFleet(userId,fleetId))
					return Convert.ToInt32(InterfaceError.AuthorizationFailed);



				// Authorize
				// TODO: 15 - > ViewFleetUsers
				LoginManager.GetInstance().AuthorizeOperation(userId,VLF.CLS.Def.Enums.OperationType.Gui,15);
				 
				DataSet dsInfo = null;
				Fleet dbFleet = null;
				try
				{
					dbFleet = new Fleet(Application["ConnectionString"].ToString());
					dsInfo = dbFleet.GetUnassignedUsersInfoByFleetId(fleetId);
				}
				finally
				{
					if(dbFleet != null)
						dbFleet.Dispose();
				}

				if(dsInfo != null && dsInfo.Tables.Count > 0 && dsInfo.Tables[0].Rows.Count > 0 )
				{
					xml = dsInfo.GetXml() ;
				}
				return (int)InterfaceError.NoError ;
			}
			catch( Exception Ex )
			{
				return (int)ASIErrorCheck.CheckError( Ex ) ;
			}			
		}
		[WebMethod(Description="Assign a user to fleet")]
		public int AddUserToFleet(int userId, string SID,int fleetId,int userIdAddToFleet)
		{
			try
			{
				Trace.WriteLineIf(AppConfig.tsWeb.Enabled|AppConfig.tsMain.TraceVerbose,CLS.Util.TraceFormat(CLS.Def.Enums.TraceSeverity.WebInterfaces,string.Format("AddUserToFleet( userId = {0}, fleetId = {1}, userIdAddToFleet = {2} )", userId,fleetId,userIdAddToFleet )));

				// Authenticate 
				LoginManager.GetInstance().SecurityCheck( userId, SID ) ;


				//Authorization
				VLF.DAS.Logic.User   dbUser=new User (Application["ConnectionString"].ToString()); 
				if (!dbUser.ValidateSuperUser(userId))
					return Convert.ToInt32(InterfaceError.AuthorizationFailed);



				// Authorize
				// TODO: 13 - > AddUserToFleet
				LoginManager.GetInstance().AuthorizeOperation(userId,VLF.CLS.Def.Enums.OperationType.Gui,13);

				Fleet dbFleet = null;
				try
				{
					dbFleet = new Fleet(Application["ConnectionString"].ToString());
					dbFleet.AddUserToFleet(fleetId,userIdAddToFleet);
				}
				finally
				{
					if(dbFleet != null)
						dbFleet.Dispose();
				}
				return (int)InterfaceError.NoError ;
			}
			catch( Exception Ex )
			{
				return (int)ASIErrorCheck.CheckError( Ex ) ;
			}
		}
		
		[WebMethod(Description="Remove a user from fleet")]
		public int DeleteUserFromFleet(int userId, string SID,int fleetId, int userIdDeleteFromFleet)
		{
			try
			{
				Trace.WriteLineIf(AppConfig.tsWeb.Enabled|AppConfig.tsMain.TraceVerbose,CLS.Util.TraceFormat(CLS.Def.Enums.TraceSeverity.WebInterfaces,string.Format("DeleteUserFromFleet( userId = {0}, fleetId = {1}, userIdDeleteFromFleet = {2} )", userId,fleetId,userIdDeleteFromFleet )));

				// Authenticate 
				LoginManager.GetInstance().SecurityCheck( userId, SID ) ;


				//Authorization
				VLF.DAS.Logic.User   dbUser=new User (Application["ConnectionString"].ToString()); 
				if (!dbUser.ValidateUserFleet(userId,fleetId))
					return Convert.ToInt32(InterfaceError.AuthorizationFailed);



				// Authorize
				// TODO: 14 - > DeleteUserFromFleet
				LoginManager.GetInstance().AuthorizeOperation(userId,VLF.CLS.Def.Enums.OperationType.Gui,14);

				Fleet dbFleet = null;
				try
				{
					dbFleet = new Fleet(Application["ConnectionString"].ToString());
					dbFleet.DeleteUserFromFleet(fleetId,userIdDeleteFromFleet);
				}
				finally
				{
					if(dbFleet != null)
						dbFleet.Dispose();
				}
				return (int)InterfaceError.NoError ;
			}
			catch( Exception Ex )
			{
				return (int)ASIErrorCheck.CheckError( Ex ) ;
			}
		}
		#endregion

		#region Fleet Emails Interfaces
		/// <summary>
		/// Add email to fleet.
		/// </summary>
		/// <param name="userId" param></param> 
		/// <param name="SID" param></param> 
		/// <param name="fleetId"></param>
		/// <param name="email"></param>
		/// <param name="timeZone"></param>
		/// <param name="dayLightSaving"></param>
		/// <param name="formatType"></param>
		/// <param name="notify"></param>
		/// <param name="warning"></param>
		/// <param name="critical"></param>
		/// <exception cref="DASAppDataAlreadyExistsException">Thrown if email alredy exists.</exception>
		/// <exception cref="DASAppInvalidValueException">Thrown in case of incorrect value.</exception>
		/// <exception cref="DASException">Thrown DASException in all other exception cases.</exception>
		[WebMethod(Description="Add a email address to fleet. This email will be notify in case of alarm")]
		public int AddEmail(int userId, string SID, int fleetId, string email,short timeZone,
			short dayLightSaving,short formatType,bool notify,bool warning,bool critical,bool autoAdjustDayLightSaving)
		{
			try
			{
				Trace.WriteLineIf(AppConfig.tsWeb.Enabled|AppConfig.tsMain.TraceVerbose,CLS.Util.TraceFormat(CLS.Def.Enums.TraceSeverity.WebInterfaces,string.Format("AddEmail( userId = {0}, fleetId = {1}, email = {2}, timeZone = {3}, dayLightSaving = {4}, formatType = {5}, notify = {6}, warning = {7}, critical = {8}, autoAdjustDayLightSaving = {9} )", userId, fleetId,email,timeZone,dayLightSaving,formatType,notify,warning,critical,autoAdjustDayLightSaving)));

				// Authenticate & Authorize
				LoginManager.GetInstance().SecurityCheck( userId, SID ) ;


				//Authorization
				VLF.DAS.Logic.User   dbUser=new User (Application["ConnectionString"].ToString()); 
				if (!dbUser.ValidateUserFleet(userId,fleetId))
					return Convert.ToInt32(InterfaceError.AuthorizationFailed);



				Fleet dbFleet = null;
				try
				{
					dbFleet = new Fleet(Application["ConnectionString"].ToString());
					dbFleet.AddEmail(fleetId,email,timeZone,dayLightSaving,formatType,notify,warning,critical,autoAdjustDayLightSaving);
				}
				finally
				{
					if(dbFleet != null)
						dbFleet.Dispose();
				}
				return (int)InterfaceError.NoError ;
			}
			catch( Exception Ex )
			{
				return (int)ASIErrorCheck.CheckError( Ex ) ;
			}
		}		
		/// <summary>
		/// Update fleet email.
		/// </summary>
		/// <param name="userId" param></param> 
		/// <param name="SID" param></param> 
		/// <param name="fleetId"></param>
		/// <param name="oldEmail"></param>
		/// <param name="newEmail"></param>
		/// <param name="timeZone"></param>
		/// <param name="dayLightSaving"></param>
		/// <param name="formatType"></param>
		/// <param name="notify"></param>
		/// <param name="warning"></param>
		/// <param name="critical"></param>
		/// <returns>void</returns>
		/// <exception cref="DASAppViolatedIntegrityConstraintsException">Thrown if fleet does not exist.</exception>
		/// <exception cref="DASAppInvalidValueException">Thrown in case of incorrect value.</exception>
		/// <exception cref="DASException">Thrown DASException in all other exception cases.</exception>
		[WebMethod(Description="Update a email address. This email will be notify in case of alarm")]
		public int UpdateEmail(int userId, string SID, int fleetId, string oldEmail, string newEmail,short timeZone,
			short dayLightSaving,short formatType,bool notify,bool warning,bool critical,bool autoAdjustDayLightSaving)
		{
			try
			{
				Trace.WriteLineIf(AppConfig.tsWeb.Enabled|AppConfig.tsMain.TraceVerbose,CLS.Util.TraceFormat(CLS.Def.Enums.TraceSeverity.WebInterfaces,string.Format("UpdateEmail( userId = {0}, fleetId = {1}, oldEmail = {2}, newEmail = {3}, timeZone = {4}, dayLightSaving = {5}, formatType = {6}, notify = {7}, warning = {8}, critical = {9}, autoAdjustDayLightSaving = {10} )", userId, fleetId,oldEmail,newEmail,timeZone,dayLightSaving,formatType,notify,warning,critical,autoAdjustDayLightSaving )));

				// Authenticate & Authorize
				LoginManager.GetInstance().SecurityCheck( userId, SID ) ;

				//Authorization
				VLF.DAS.Logic.User   dbUser=new User (Application["ConnectionString"].ToString()); 
				if (!dbUser.ValidateUserFleet(userId,fleetId))
					return Convert.ToInt32(InterfaceError.AuthorizationFailed);



				Fleet dbFleet = null;
				try
				{
					dbFleet = new Fleet(Application["ConnectionString"].ToString());
					dbFleet.UpdateEmail(fleetId,oldEmail,newEmail,timeZone,dayLightSaving,formatType,notify,warning,critical,autoAdjustDayLightSaving);
				}
				finally
				{
					if(dbFleet != null)
						dbFleet.Dispose();
				}
				return (int)InterfaceError.NoError ;
			}
			catch( Exception Ex )
			{
				return (int)ASIErrorCheck.CheckError( Ex ) ;
			}
		}
		/// <summary>
		/// Delete existing email from fleet.
		/// </summary>
		/// <returns>rows affected</returns>
		/// <param name="userId" param></param> 
		/// <param name="SID" param></param> 
		/// <param name="fleetId"></param> 
		/// <param name="email"></param> 
		/// <exception cref="DASAppResultNotFoundException">Thrown if fleet does not exist</exception>
		/// <exception cref="DASException">Thrown DASException in all other exception cases.</exception>
		[WebMethod(Description="Remove a email address from fleet.")]
		public int DeleteEmailFromFleet(int userId, string SID, int fleetId,string email)
		{
			try
			{
				Trace.WriteLineIf(AppConfig.tsWeb.Enabled|AppConfig.tsMain.TraceVerbose,CLS.Util.TraceFormat(CLS.Def.Enums.TraceSeverity.WebInterfaces,string.Format("DeleteEmailFromFleet( userId = {0}, fleetId = {1}, email = {2} )", userId, fleetId,email )));

				// Authenticate & Authorize
				LoginManager.GetInstance().SecurityCheck( userId, SID ) ;

				//Authorization
				VLF.DAS.Logic.User   dbUser=new User (Application["ConnectionString"].ToString()); 
				if (!dbUser.ValidateUserFleet(userId,fleetId))
					return Convert.ToInt32(InterfaceError.AuthorizationFailed);



				Fleet dbFleet = null;
				try
				{
					dbFleet = new Fleet(Application["ConnectionString"].ToString());
					dbFleet.DeleteEmailFromFleet(fleetId,email);
				}
				finally
				{
					if(dbFleet != null)
						dbFleet.Dispose();
				}
				return (int)InterfaceError.NoError ;
			}
			catch( Exception Ex )
			{
				return (int)ASIErrorCheck.CheckError( Ex ) ;
			}
		}
		/// <summary>
		/// Delete all emails from fleet.
		/// </summary>
		/// <returns>rows affected</returns>
		/// <param name="userId" param></param> 
		/// <param name="SID" param></param> 
		/// <param name="fleetId"></param> 
		/// <exception cref="DASAppResultNotFoundException">Thrown if fleet id does not exist</exception>
		/// <exception cref="DASException">Thrown DASException in all other exception cases.</exception>
		[WebMethod(Description="Delete all email addresses from fleet.")]
		public int DeleteAllEmailsFromFleet(int userId, string SID, int fleetId)
		{
			try
			{
				Trace.WriteLineIf(AppConfig.tsWeb.Enabled|AppConfig.tsMain.TraceVerbose,CLS.Util.TraceFormat(CLS.Def.Enums.TraceSeverity.WebInterfaces,string.Format("DeleteAllEmailsFromFleet( userId = {0}, fleetId = {1} )", userId, fleetId )));

				// Authenticate & Authorize
				LoginManager.GetInstance().SecurityCheck( userId, SID ) ;

				//Authorization
				VLF.DAS.Logic.User   dbUser=new User (Application["ConnectionString"].ToString()); 
				if (!dbUser.ValidateUserFleet(userId,fleetId))
					return Convert.ToInt32(InterfaceError.AuthorizationFailed);



				Fleet dbFleet = null;
				try
				{
					dbFleet = new Fleet(Application["ConnectionString"].ToString());
					dbFleet.DeleteAllEmailsFromFleet(fleetId);
				}
				finally
				{
					if(dbFleet != null)
						dbFleet.Dispose();
				}
				return (int)InterfaceError.NoError ;
			}
			catch( Exception Ex )
			{
				return (int)ASIErrorCheck.CheckError( Ex ) ;
			}
		}
		//// <summary>
		/// Retrieves fleet emails
		/// </summary>
		/// <returns>XML [FleetId],[FleetMame],[Email],[TimeZone],
		/// [DayLightSaving],[FormatType],[Notify],[Warning],[Critical]</returns>
		/// <param name="userId" param></param> 
		/// <param name="SID" param></param> 
		/// <param name="fleetId" param></param> 
		/// <exception cref="DASException">Thrown DASException in all  exception cases.</exception>
		[WebMethod(Description="Returns XML of all email addresses assigned to fleet. XML File format:XML [FleetId],[FleetMame],[Email],[TimeZone],[DayLightSaving],[FormatType],[Notify],[Warning],[Critical]")]
		public int GetFleetEmailsXML(int userId, string SID, int fleetId ,ref string xml)
		{
			try
			{
				Trace.WriteLineIf(AppConfig.tsWeb.Enabled|AppConfig.tsMain.TraceVerbose,CLS.Util.TraceFormat(CLS.Def.Enums.TraceSeverity.WebInterfaces,string.Format("GetFleetEmailsXML( userId = {0}, fleetId = {1} )", userId, fleetId )));

				// Authenticate & Authorize
				LoginManager.GetInstance().SecurityCheck( userId, SID ) ;

				//Authorization
				VLF.DAS.Logic.User   dbUser=new User (Application["ConnectionString"].ToString()); 
				if (!dbUser.ValidateUserFleet(userId,fleetId))
					return Convert.ToInt32(InterfaceError.AuthorizationFailed);



				DataSet dsInfo = null;
				Fleet dbFleet = null;
				try
				{
					dbFleet = new Fleet(Application["ConnectionString"].ToString());
					dsInfo = dbFleet.GetFleetEmails(fleetId);
				}
				finally
				{
					if(dbFleet != null)
						dbFleet.Dispose();
				}
				if(dsInfo != null && dsInfo.Tables.Count > 0 && dsInfo.Tables[0].Rows.Count > 0 )
				{
					xml = dsInfo.GetXml() ;
				}
				return (int)InterfaceError.NoError ;
			}
			catch( Exception Ex )
			{
				return (int)ASIErrorCheck.CheckError( Ex ) ;
			}	
		}
		[WebMethod(Description="Set Daylight Saving adjustment to the notification email")]
		public int SetFleetAutoAdjustDayLightSaving(int userId, string SID,int fleetId,string email,bool autoAdjustDayLightSaving,bool dayLightSaving)
		{
			try
			{
				Trace.WriteLineIf(AppConfig.tsWeb.Enabled|AppConfig.tsMain.TraceVerbose,CLS.Util.TraceFormat(CLS.Def.Enums.TraceSeverity.WebInterfaces,string.Format("SetFleetAutoAdjustDayLightSaving( fleetId = {0}, email = '{1}', autoAdjustDayLightSaving = {2} , dayLightSaving = {3} )", fleetId,email,autoAdjustDayLightSaving,dayLightSaving )));

				// Authenticate & Authorize
				LoginManager.GetInstance().SecurityCheck( userId, SID ) ;

				//Authorization
				VLF.DAS.Logic.User   dbUser=new User (Application["ConnectionString"].ToString()); 
				if (!dbUser.ValidateUserFleet(userId,fleetId))
					return Convert.ToInt32(InterfaceError.AuthorizationFailed);



				SystemConfig dbSystem = null;
				try
				{
					dbSystem = new SystemConfig(Application["ConnectionString"].ToString());
					dbSystem.SetFleetAutoAdjustDayLightSaving(fleetId,email,autoAdjustDayLightSaving,dayLightSaving);
				}
				finally
				{
					if(dbSystem != null)
						dbSystem.Dispose();
				}
				return (int)InterfaceError.NoError ;
			}
			catch( Exception Ex )
			{
				return (int)ASIErrorCheck.CheckError( Ex ) ;
			}
		}
		#endregion
	}
}
