using System;
using System.Data;
using System.Configuration;
using System.IO; 


namespace SentinelFM
{
	/// <summary>
	/// Summary description for clsUser.
	/// </summary>
	public class clsUser
	{

		
		ServerDBUser.DBUser dbu  ;
		protected clsUtility objUtil;


	
		

        private VLF.MAP.MapEngine<VLF.MAP.MapType>[] mapEngine;
        public VLF.MAP.MapEngine<VLF.MAP.MapType>[] MapEngine
		{
            get { return mapEngine; }
            set { mapEngine = value; }
		}

        private VLF.MAP.MapEngine<VLF.MAP.GeoCodeType>[] geoCodeEngine;
        public VLF.MAP.MapEngine<VLF.MAP.GeoCodeType>[] GeoCodeEngine
		{
            get { return geoCodeEngine; }
            set { geoCodeEngine = value; }
		}

		private int defaultFleet=-1;
		public int DefaultFleet
		{
			get{return defaultFleet;}
			set{defaultFleet = value;}
		}

		private double unitOfMes=0.6214;
		public double UnitOfMes
		{
			get{return unitOfMes;}
			set{unitOfMes = value;}
		}


		private Int16 timeZone=0;
		public Int16 TimeZone
		{
			get{return timeZone;}
			set{timeZone = value;}
		}


		private Int16 dayLightSaving=0;
		public Int16 DayLightSaving
		{
			get{return dayLightSaving;}
			set{dayLightSaving = value;}
		}

		private Int16 showReadMess=0;
		public Int16 ShowReadMess
		{
			get{return showReadMess;}
			set{showReadMess = value;}
		}

		private Int32 alarmRefreshFrequency=60000;
		public Int32 AlarmRefreshFrequency
		{
			get{return alarmRefreshFrequency;}
			set{alarmRefreshFrequency = value;}
		}

		private Int32 generalRefreshFrequency=60000;
		public Int32 GeneralRefreshFrequency
		{
			get{return generalRefreshFrequency;}
			set{generalRefreshFrequency = value;}
		}

		private Int64 positionExpiredTime=VLF.CLS.Def.Const.PositionExpiredTime;   
		public Int64 PositionExpiredTime
		{
			get{return positionExpiredTime;}
			set{positionExpiredTime = value;}
		}

		private string firstName="";
		public string FirstName
		{
			get{return firstName;}
			set{firstName = value;}
		}


		private string lastName="";
		public string LastName
		{
			get{return lastName;}
			set{lastName = value;}
		}


		private string ipAddr="";
		public string IPAddr
		{
			get{return ipAddr;}
			set{ipAddr = value;}
		}


		private string organizationName="";
		public string OrganizationName
		{
			get{return organizationName;}
			set{organizationName = value;}
		}



		private string companyLogo="";
		public string CompanyLogo
		{
			get{return companyLogo;}
			set{companyLogo = value;}
		}


		private string companyURL="";
		public string CompanyURL
		{
			get{return companyURL;}
			set{companyURL = value;}
		}

		private Int32 organizationId=0;
		public Int32 OrganizationId
		{
			get{return organizationId;}
			set{organizationId = value;}
		}

		

		private DataSet dsGUIControls;
		public DataSet DsGUIControls
		{
			get{return dsGUIControls;}
			set{dsGUIControls = value;}
		}



      private string selectedLanguage;
      public string  SelectedLanguage
      {
         get { return selectedLanguage; }
         set { selectedLanguage = value; }
      }


      private int screenWidth;
      public int ScreenWidth
      {
         get { return screenWidth; }
         set { screenWidth = value; }
      }

      private int screenHeight;
      public int ScreenHeight
      {
         get { return screenHeight; }
         set { screenHeight = value; }
      }

      private string fleetPulseURL;
      public string FleetPulseURL
      {
         get { return fleetPulseURL; }
         set { fleetPulseURL = value; }
      }


      private Int16  viewMDTMessagesScrolling = 0;
      public Int16 ViewMDTMessagesScrolling
      {
         get { return viewMDTMessagesScrolling; }
         set { viewMDTMessagesScrolling = value; }
      }


      private Int16 showMapGridFilter = 1;
      public Int16 ShowMapGridFilter
      {
         get { return showMapGridFilter; }
         set { showMapGridFilter = value; }
      }

		public void ExistingPreference(SentinelFMSession sn)
		{

			try
			{
				
				if ((sn==null) || (sn.UserName=="") )
				{
					return ;
				}


				dbu = new ServerDBUser.DBUser()  ;
				objUtil=new clsUtility(sn) ;

				string xml = "" ;
				StringReader strrXML = null;
				DataSet dsUser=new DataSet();
				ServerDBOrganization.DBOrganization dbo = new ServerDBOrganization.DBOrganization() ;

				if( objUtil.ErrCheck( dbu.GetUserInfoByUserId( sn.UserID , sn.SecId , ref xml ),false ) )
					if( objUtil.ErrCheck( dbu.GetUserInfoByUserId( sn.UserID , sn.SecId, ref xml ), true ) )
					{
						System.Diagnostics.Trace.WriteLineIf(AppConfig.tsMain.TraceError,VLF.CLS.Util.TraceFormat(VLF.CLS.Def.Enums.TraceSeverity.Error,"GetUserInfoByUserId. User:"+sn.UserID.ToString()+" Form:Login.aspx"));    
					}
				if (xml != "")
				{
					strrXML = new StringReader( xml ) ;
					dsUser.ReadXml (strrXML) ;

					sn.User.LastName=dsUser.Tables[0].Rows[0]["LastName"].ToString();  
					sn.User.FirstName =dsUser.Tables[0].Rows[0]["FirstName"].ToString();  
					sn.User.OrganizationName =dsUser.Tables[0].Rows[0]["OrganizationName"].ToString();
					sn.User.OrganizationId=Convert.ToInt32(dsUser.Tables[0].Rows[0]["OrganizationId"]);
               sn.User.FleetPulseURL = dsUser.Tables[0].Rows[0]["FleetPulseURL"].ToString() ;  
				
				}

                ServerDBSystem.DBSystem dbs = new ServerDBSystem.DBSystem();
                DataSet dsGeoCodeEngines = new DataSet();
                DataSet dsMapEngines = new DataSet();
                if (objUtil.ErrCheck(dbs.GetUserGeoCodeEngineInfoXML(sn.UserID, sn.SecId, ref xml), false))
                    if (objUtil.ErrCheck(dbs.GetUserGeoCodeEngineInfoXML(sn.UserID, sn.SecId, ref xml), true))
                    {
                        System.Diagnostics.Trace.WriteLineIf(AppConfig.tsMain.TraceError, VLF.CLS.Util.TraceFormat(VLF.CLS.Def.Enums.TraceSeverity.Error, "GetGeoCodeEnginesInfo. User:" + sn.UserID.ToString() + " Form:Login.aspx"));
                    }
                if (xml != "")
                {
                    strrXML = new StringReader(xml);
                    dsGeoCodeEngines.ReadXml(strrXML);

                    sn.User.GeoCodeEngine = VLF.MAP.MapUtilities.ConvertGeoCodersToMapEngine(dsGeoCodeEngines);
                }
                if (objUtil.ErrCheck(dbs.GetUserMapEngineInfoXML(sn.UserID, sn.SecId, ref xml), false))
                    if (objUtil.ErrCheck(dbs.GetUserMapEngineInfoXML (sn.UserID, sn.SecId, ref xml), true))
                    {
                        System.Diagnostics.Trace.WriteLineIf(AppConfig.tsMain.TraceError, VLF.CLS.Util.TraceFormat(VLF.CLS.Def.Enums.TraceSeverity.Error, "GetUserMapEngineInfoXML. User:" + sn.UserID.ToString() + " Form:Login.aspx"));
                    }
                if (xml != "")
                {

                   if (sn.User.OrganizationId != 219)
                     xml = "<System><GetUserMapEngineInfo><MapId>" + ConfigurationSettings.AppSettings["StaticMapId"] + "</MapId><Path>" + ConfigurationSettings.AppSettings["MapInternalPath"] + "</Path><ExternalPath>" + ConfigurationSettings.AppSettings["MapExternalPath"] + "</ExternalPath></GetUserMapEngineInfo></System>";
		    
                    strrXML = new StringReader(xml);
                    dsMapEngines.ReadXml(strrXML);
                     
                    sn.User.MapEngine = VLF.MAP.MapUtilities.ConvertMapsToMapEngine(dsMapEngines);
                   if (sn.User.MapEngine[0].MapEngineID.ToString() == "MapsoluteWeb")
                       sn.MapForm = "MapsoluteMap";
                }

				//Company Logo and home Page
				xml="";
				if( objUtil.ErrCheck( dbo.GetOrganizationInfoXMLByUserId     ( sn.UserID ,sn.SecId , ref xml ),false ) )
					if( objUtil.ErrCheck( dbo.GetOrganizationInfoXMLByUserId    ( sn.UserID , sn.SecId , ref xml ),true ) )
					{
						System.Diagnostics.Trace.WriteLineIf(AppConfig.tsMain.TraceError,VLF.CLS.Util.TraceFormat(VLF.CLS.Def.Enums.TraceSeverity.Error,"GetOrganizationInfoXMLByUserId. User:"+sn.UserID.ToString()+" Form:Login.aspx"));    
					}

				if (xml == "")
				{
					sn.User.CompanyLogo=ConfigurationSettings.AppSettings["DefaultLogo"];
					sn.User.CompanyURL=ConfigurationSettings.AppSettings["DefaultCompanyURL"];  
				}
				else
				{

					DataSet dsCompany=new DataSet();
					strrXML = new StringReader( xml ) ;
					dsCompany.ReadXml (strrXML) ;


					


					try
					{
						sn.User.CompanyLogo=dsCompany.Tables[0].Rows[0]["LogoName"].ToString().TrimEnd();     
					}
					catch
					{
						sn.User.CompanyLogo=ConfigurationSettings.AppSettings["DefaultLogo"];
					}

					try
					{
						sn.User.CompanyURL=dsCompany.Tables[0].Rows[0]["HomePageName"].ToString().TrimEnd();
					}
					catch
					{
						sn.User.CompanyURL=ConfigurationSettings.AppSettings["DefaultCompanyURL"];  
					}
				
					

					

				}
				xml="";
				DataSet dsPref=new DataSet();
				if( objUtil.ErrCheck( dbu.GetUserPreferencesXML  ( sn.UserID , sn.SecId , ref xml ),false ) )
					if( objUtil.ErrCheck( dbu.GetUserPreferencesXML( sn.UserID , sn.SecId, ref xml ), true ) )
					{
						System.Diagnostics.Trace.WriteLineIf(AppConfig.tsMain.TraceError,VLF.CLS.Util.TraceFormat(VLF.CLS.Def.Enums.TraceSeverity.Error,"GetUserPreferencesXML. User:"+sn.UserID.ToString()+" Form:Login.aspx"));    
					}
				if (xml != "")
				{
					strrXML = new StringReader( xml ) ;
					dsPref.ReadXml (strrXML) ;

                    Int16 PreferenceId = 0;

					foreach(DataRow rowItem in dsPref.Tables[0].Rows)
					{
                        PreferenceId=Convert.ToInt16(rowItem["PreferenceId"]);
                        switch (PreferenceId)
                        {
                            case (Int16)VLF.CLS.Def.Enums.Preference.MeasurementUnits:
                                if (rowItem["PreferenceValue"].ToString().TrimEnd() != "")
                                    sn.User.UnitOfMes = Convert.ToDouble(rowItem["PreferenceValue"].ToString().TrimEnd());

                                break;
                            case (Int16)VLF.CLS.Def.Enums.Preference.TimeZone:
                                if (rowItem["PreferenceValue"].ToString().TrimEnd() != "")
                                    sn.User.TimeZone = Convert.ToInt16(rowItem["PreferenceValue"].ToString().TrimEnd());
                                break;
                            case (Int16)VLF.CLS.Def.Enums.Preference.DefaultFleet :     
                                if (rowItem["PreferenceValue"].ToString().TrimEnd() !="")
							    	sn.User.DefaultFleet=Convert.ToInt16(rowItem["PreferenceValue"].ToString().TrimEnd()) ;
                                break;
                            case (Int16)VLF.CLS.Def.Enums.Preference.DayLightSaving:
                                if (rowItem["PreferenceValue"].ToString().TrimEnd() == "1")
                                    sn.User.DayLightSaving = 1;
                                else
                                    sn.User.DayLightSaving = 0;
                                break;
                            case (Int16)VLF.CLS.Def.Enums.Preference.MapOptShowVehicleName:
                                if (rowItem["PreferenceValue"].ToString().TrimEnd() == "0")
                                    sn.Map.ShowVehicleName = false;
                                else
                                    sn.Map.ShowVehicleName = true;
                                break;
                            case (Int16)VLF.CLS.Def.Enums.Preference.MapOptShowLandmark:
                                if (rowItem["PreferenceValue"].ToString().TrimEnd() == "0")
                                    sn.Map.ShowLandmark = false;
                                else
                                    sn.Map.ShowLandmark = true;
                                break;
                           case (Int16)VLF.CLS.Def.Enums.Preference.MapOptShowLandmarkName:
                               if (rowItem["PreferenceValue"].ToString().TrimEnd() == "0")
                                   sn.Map.ShowLandmarkname = false;
                               else
                                   sn.Map.ShowLandmarkname = true;
                               break;
                           case (Int16)VLF.CLS.Def.Enums.Preference.MapOptShowBreadCrumbTrail:
                               if (rowItem["PreferenceValue"].ToString().TrimEnd() == "1")
                                   sn.History.ShowBreadCrumb = true;
                               else
                                   sn.History.ShowBreadCrumb = false;
                               break;
                           case (Int16)VLF.CLS.Def.Enums.Preference.MapOptShowStopSequenceNo:
                               if (rowItem["PreferenceValue"].ToString().TrimEnd() == "1")
                                   sn.History.ShowStopSqNum = true;
                               else
                                   sn.History.ShowStopSqNum = false;
                               break;
                           case (Int16)VLF.CLS.Def.Enums.Preference.ShowReadMessages:
                               if (rowItem["PreferenceValue"].ToString().TrimEnd() == "1")
                                   sn.User.showReadMess = 1;
                               else
                                   sn.User.showReadMess = 0;
                               break;
                           case (Int16)VLF.CLS.Def.Enums.Preference.AlarmRefreshFrequency:
                                if (rowItem["PreferenceValue"].ToString().TrimEnd() !="")
							    	sn.User.AlarmRefreshFrequency =Convert.ToInt32(rowItem["PreferenceValue"].ToString().TrimEnd()) ;
                                break;
                            case (Int16)VLF.CLS.Def.Enums.Preference.GeneralRefreshFrequency:
                                if (rowItem["PreferenceValue"].ToString().TrimEnd() != "")
                                    sn.User.GeneralRefreshFrequency = Convert.ToInt32(rowItem["PreferenceValue"].ToString().TrimEnd());
                                break;
                            case (Int16)VLF.CLS.Def.Enums.Preference.PositionExpiredTime:
                                if (rowItem["PreferenceValue"].ToString().TrimEnd() != "")
                                    sn.User.PositionExpiredTime = Convert.ToInt64(rowItem["PreferenceValue"].ToString().TrimEnd());
                                break;

                             case (Int16)VLF.CLS.Def.Enums.Preference.MapGridDefaultRows:
                                if (rowItem["PreferenceValue"].ToString().TrimEnd() != "")
                                   sn.Map.DgVisibleRows = Convert.ToInt32(rowItem["PreferenceValue"].ToString().TrimEnd());
                                break;

                             case (Int16)VLF.CLS.Def.Enums.Preference.HistoryGridDefaultRows:
                                if (rowItem["PreferenceValue"].ToString().TrimEnd() != "")
                                   sn.History.DgVisibleRows = Convert.ToInt32(rowItem["PreferenceValue"].ToString().TrimEnd());
                                break;

                             case (Int16)VLF.CLS.Def.Enums.Preference.ViewMDTMessagesScrolling:
                                if (rowItem["PreferenceValue"].ToString().TrimEnd() != "")
                                   sn.User.ViewMDTMessagesScrolling  = Convert.ToInt16(rowItem["PreferenceValue"].ToString().TrimEnd());
                                break;

                             case (Int16)VLF.CLS.Def.Enums.Preference.ShowMapGridFilter :
                                if (rowItem["PreferenceValue"].ToString().TrimEnd() != "")
                                   sn.User.ShowMapGridFilter = Convert.ToInt16(rowItem["PreferenceValue"].ToString().TrimEnd());
                                break;
                        }
			
					}
				}


				
				xml="";
				if( objUtil.ErrCheck( dbo.GetOrganizationLandmarksXMLByOrganizationId  ( sn.UserID , sn.SecId ,sn.User.OrganizationId, ref xml ),false ) )
					if( objUtil.ErrCheck( dbo.GetOrganizationLandmarksXMLByOrganizationId  ( sn.UserID , sn.SecId ,sn.User.OrganizationId, ref xml ),true ) )
					{
						System.Diagnostics.Trace.WriteLineIf(AppConfig.tsMain.TraceError,VLF.CLS.Util.TraceFormat(VLF.CLS.Def.Enums.TraceSeverity.Error,"GetOrganizationLandmarksXMLByOrganizationId. User:"+sn.UserID.ToString()+" Form:Login.aspx"));    
					}

				if (xml != "")
				{
					strrXML = new StringReader( xml ) ;
					DataSet ds=new DataSet();
					ds.ReadXml (strrXML) ;
					sn.DsLandMarks=ds;
				}
				else
				{
					sn.DsLandMarks=null;
				}
			

			

			}
		
			catch(System.Threading.ThreadAbortException)
			{
				return;
			}
			catch(Exception Ex)
			{
				System.Diagnostics.Trace.WriteLineIf(AppConfig.tsMain.TraceError,VLF.CLS.Util.TraceFormat(VLF.CLS.Def.Enums.TraceSeverity.Error,Ex.Message.ToString()+" User:"+sn.UserID.ToString()+" Form:Login.aspx"));    
			}
		}




		public bool ControlEnable(SentinelFMSession sn,int ControlId)
		{
			try
			{
				bool ControlStatus=false;

				if (sn.User.DsGUIControls!=null)
				{
					foreach(DataRow rowItem in sn.User.DsGUIControls.Tables[0].Rows)
					{
						if (Convert.ToInt32(rowItem["ControlId"])==Convert.ToInt32(ControlId))
						{
							ControlStatus=true;
							break;
						}
					}
				}

				return ControlStatus;
			}
		 catch
			{
				return false;
			}
		}

		public clsUser()
		{
			//
			// TODO: Add constructor logic here
			//
		}
	}
}
